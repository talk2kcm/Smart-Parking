import logging
import uuid
from datetime import datetime, timezone

from bson import ObjectId
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError, PyMongoError
from redis.exceptions import RedisError

from .db import mongo
from .redis_state import OperationalStateError, apply_space_state, owned_lock

logger = logging.getLogger(__name__)


# Coordination contention and domain conflicts are both safe, retryable
# request conflicts at the service boundary. Sharing the exception type keeps
# concurrent lock losers out of Flask's generic 500 handler.
ParkingConflict = OperationalStateError


class PartialIntegrationError(RuntimeError):
    pass


def utc_now():
    return datetime.now(timezone.utc)


def _operation(operation_id, kind, space_id):
    db = mongo()
    now = utc_now()
    try:
        db.operations.insert_one({
            "operation_id": operation_id, "kind": kind, "space_id": space_id,
            "status": "prepared", "created_at": now, "updated_at": now,
        })
    except DuplicateKeyError:
        existing = db.operations.find_one({"operation_id": operation_id})
        if not existing or existing["kind"] != kind or existing["space_id"] != space_id:
            raise ParkingConflict("Operation ID was already used for a different request.")
        if existing.get("status") == "rejected":
            raise ParkingConflict(existing.get("error", "This operation was previously rejected."))
        return existing
    return db.operations.find_one({"operation_id": operation_id})


def _space_and_zone(space_id):
    db = mongo()
    space = db.spaces.find_one({"_id": space_id})
    if not space:
        raise ParkingConflict("Parking space does not exist.")
    zone = db.zones.find_one({"_id": space["zone_id"]})
    if not zone:
        raise ParkingConflict("The space has no valid parking zone.")
    if not space.get("active") or not zone.get("active"):
        raise ParkingConflict("Entry is unavailable because the space or zone is inactive.")
    return space, zone


def _mark_synced(operation_id):
    mongo().operations.update_one(
        {"operation_id": operation_id},
        {"$set": {"status": "synced", "updated_at": utc_now()}, "$unset": {"error": ""}},
    )


def _reject(operation_id, message):
    mongo().operations.update_one(
        {"operation_id": operation_id, "status": "prepared"},
        {"$set": {"status": "rejected", "error": message, "updated_at": utc_now()}},
    )
    raise ParkingConflict(message)


def record_entry(space_id, vehicle_id=None, operation_id=None, entered_at=None):
    operation_id = operation_id or str(uuid.uuid4())
    entered_at = entered_at or utc_now()
    if entered_at.tzinfo is None:
        raise ParkingConflict("Entry timestamp must include a timezone.")
    db = mongo()
    with owned_lock(f"space:{space_id}"):
        operation = _operation(operation_id, "entry", space_id)
        if operation.get("status") == "synced":
            return db.sessions.find_one({"entry_operation_id": operation_id}), True
        try:
            space, _zone = _space_and_zone(space_id)
        except ParkingConflict as exc:
            _reject(operation_id, str(exc))
        session = db.sessions.find_one({"entry_operation_id": operation_id})
        if not session:
            if db.sessions.find_one({"space_id": space_id, "exit_at": None}):
                _reject(operation_id, "This parking space is already occupied.")
            try:
                result = db.sessions.insert_one({
                    "space_id": space_id, "zone_id": space["zone_id"], "space_code": space["code"],
                    "vehicle_id": (vehicle_id or "").strip()[:40] or None,
                    "entry_at": entered_at.astimezone(timezone.utc), "exit_at": None,
                    "duration_seconds": None, "entry_operation_id": operation_id,
                    "exit_operation_id": None, "created_at": utc_now(),
                })
                session = db.sessions.find_one({"_id": result.inserted_id})
            except DuplicateKeyError as exc:
                session = db.sessions.find_one({"entry_operation_id": operation_id})
                if not session:
                    _reject(operation_id, "A concurrent entry already occupied this space.")
        updated_space = db.spaces.find_one_and_update(
            {"_id": space_id}, {"$inc": {"state_version": 1}, "$set": {"updated_at": utc_now()}},
            return_document=ReturnDocument.AFTER,
        )
        db.operations.update_one(
            {"operation_id": operation_id},
            {"$set": {"status": "mongo_applied", "session_id": session["_id"],
                      "state_version": updated_space["state_version"], "updated_at": utc_now()}},
        )
        try:
            apply_space_state(space_id, space["zone_id"], "occupied", updated_space["state_version"])
            _mark_synced(operation_id)
        except (RedisError, OperationalStateError) as exc:
            db.operations.update_one({"operation_id": operation_id}, {"$set": {"status": "pending_redis", "error": str(exc), "updated_at": utc_now()}})
            logger.exception("Entry persisted but Redis sync is pending for operation %s", operation_id)
            raise PartialIntegrationError(
                f"Entry was durably recorded, but live availability is pending synchronisation. Operation ID: {operation_id}"
            ) from exc
        return session, False


def record_exit(space_id, operation_id=None, exited_at=None):
    operation_id = operation_id or str(uuid.uuid4())
    exited_at = exited_at or utc_now()
    if exited_at.tzinfo is None:
        raise ParkingConflict("Exit timestamp must include a timezone.")
    db = mongo()
    with owned_lock(f"space:{space_id}"):
        operation = _operation(operation_id, "exit", space_id)
        if operation.get("status") == "synced":
            return db.sessions.find_one({"exit_operation_id": operation_id}), True
        space = db.spaces.find_one({"_id": space_id})
        if not space:
            _reject(operation_id, "Parking space does not exist.")
        session = db.sessions.find_one({"exit_operation_id": operation_id})
        if not session:
            open_session = db.sessions.find_one({"space_id": space_id, "exit_at": None})
            if not open_session:
                _reject(operation_id, "This parking space is vacant; there is no open session to exit.")
            exit_utc = exited_at.astimezone(timezone.utc)
            if exit_utc < open_session["entry_at"]:
                _reject(operation_id, "Exit time cannot be earlier than entry time.")
            duration = int((exit_utc - open_session["entry_at"]).total_seconds())
            session = db.sessions.find_one_and_update(
                {"_id": open_session["_id"], "exit_at": None},
                {"$set": {"exit_at": exit_utc, "duration_seconds": duration, "exit_operation_id": operation_id}},
                return_document=ReturnDocument.AFTER,
            )
            if not session:
                _reject(operation_id, "A concurrent request already completed this exit.")
        updated_space = db.spaces.find_one_and_update(
            {"_id": space_id}, {"$inc": {"state_version": 1}, "$set": {"updated_at": utc_now()}},
            return_document=ReturnDocument.AFTER,
        )
        db.operations.update_one(
            {"operation_id": operation_id},
            {"$set": {"status": "mongo_applied", "session_id": session["_id"],
                      "state_version": updated_space["state_version"], "updated_at": utc_now()}},
        )
        try:
            new_state = "vacant" if space.get("active") else "inactive"
            apply_space_state(space_id, space["zone_id"], new_state, updated_space["state_version"])
            _mark_synced(operation_id)
        except (RedisError, OperationalStateError) as exc:
            db.operations.update_one({"operation_id": operation_id}, {"$set": {"status": "pending_redis", "error": str(exc), "updated_at": utc_now()}})
            logger.exception("Exit persisted but Redis sync is pending for operation %s", operation_id)
            raise PartialIntegrationError(
                f"Exit was durably recorded, but live availability is pending synchronisation. Operation ID: {operation_id}"
            ) from exc
        return session, False


def retry_pending_operations():
    db = mongo()
    repaired = 0
    failed = 0
    for operation in db.operations.find({"status": {"$in": ["mongo_applied", "pending_redis"]}}).sort("updated_at", 1):
        space = db.spaces.find_one({"_id": operation["space_id"]})
        if not space:
            failed += 1
            continue
        occupied = db.sessions.count_documents({"space_id": space["_id"], "exit_at": None}) > 0
        state = "inactive" if not space.get("active") else ("occupied" if occupied else "vacant")
        try:
            apply_space_state(space["_id"], space["zone_id"], state, space.get("state_version", 0), require_initialized=False)
            _mark_synced(operation["operation_id"])
            repaired += 1
        except RedisError as exc:
            logger.warning("Pending operation %s still failed: %s", operation["operation_id"], exc)
            failed += 1
    return repaired, failed
