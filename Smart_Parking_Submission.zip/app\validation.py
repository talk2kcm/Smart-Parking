from datetime import datetime, timezone
from bson import ObjectId


class ValidationError(ValueError):
    pass


def required_text(value, label, max_length=120):
    value = (value or "").strip()
    if not value:
        raise ValidationError(f"{label} is required.")
    if len(value) > max_length:
        raise ValidationError(f"{label} must be {max_length} characters or fewer.")
    return value


def optional_text(value, label, max_length=240):
    value = (value or "").strip()
    if len(value) > max_length:
        raise ValidationError(f"{label} must be {max_length} characters or fewer.")
    return value or None


def object_id(value, label="Identifier"):
    if not ObjectId.is_valid(str(value)):
        raise ValidationError(f"{label} is invalid.")
    return ObjectId(str(value))


def parse_utc_filter(value, label, end_of_day=False):
    if not value:
        return None
    try:
        parsed = datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError as exc:
        raise ValidationError(f"{label} must be a valid date in YYYY-MM-DD format.") from exc
    if end_of_day:
        from datetime import timedelta
        parsed += timedelta(days=1)
    return parsed


SPACE_TYPES = {"standard", "accessible", "electric", "motorcycle"}


def space_type(value):
    if value not in SPACE_TYPES:
        raise ValidationError("Space type is invalid.")
    return value
