# Likely questions and accurate answers

**Why use two databases?**  
The access patterns differ. MongoDB retains queryable history and recovery evidence. Redis maintains a compact current-state projection and ranking. A single relational database could be simpler; the assignment asks for a justified MongoDB/Redis integration.

**What happens if Redis fails after an entry?**  
The entry remains accepted and durable in MongoDB, but the operation becomes `pending_redis`. The UI warns that synchronisation is pending. A retry or reconciliation derives current state from MongoDB and marks the operation synced.

**Is the cross-database operation atomic?**  
No. MongoDB and Redis do not share a transaction. The system uses durable-first writes, idempotency, explicit pending state, atomic updates inside Redis, and repair.

**Why does a lock not guarantee correctness?**  
The lock has an expiry and could lapse during slow work. Token-checked release prevents one owner deleting another’s lock, but MongoDB unique indexes and monotonic versions remain the correctness safeguards.

**How are duplicate entries prevented?**  
A partial unique MongoDB index allows only one session with `exit_at: null` per space. Per-space coordination reduces races, and operation IDs make the same request safe to retry.

**How can Redis be rebuilt?**  
Active zones/spaces establish capacity; durable open sessions establish occupation. Reconciliation writes versioned states, initialises empty active zones, retries pending operations, and touches only the configured prefix.

**Why store an open session in MongoDB if Redis has occupancy?**  
The open session is historical/recovery evidence, not a copy of the whole operational dataset. Without it, Redis loss could not distinguish occupied from vacant spaces.

**What is “demand”?**  
Current demand is occupancy percentage now. Historical demand is the number of entry events in a selected period. The UI keeps them separate.

**Does this prove an emissions reduction?**  
No. It implements a plausible information mechanism. Measuring emissions would require real search-distance/time baselines, adoption data, and a defensible emissions model.

**Why might Redis be faster?**  
It retrieves a maintained counter from memory rather than calculating from durable records. The benchmark must verify this locally; the benefit has memory, write, consistency, and recovery costs.

**Would SQL be wrong?**  
No. A relational database could offer excellent constraints, joins, and one transaction boundary. The design is a context-specific polyglot solution, not a universal superiority claim.

**How is privacy handled?**  
The demo uses optional fictional identifiers. Production use would require minimisation, retention limits, access control, auditing, and applicable privacy-law review.

