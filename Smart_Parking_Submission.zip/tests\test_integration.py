from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import uuid

import pytest
from pymongo.errors import DuplicateKeyError
from redis.exceptions import RedisError

from app.db import mongo
from app.parking_service import ParkingConflict, PartialIntegrationError, record_entry, record_exit
from app.reconciliation import rebuild_redis, verify_invariants
from app.redis_state import clear_project_state, zone_counts

pytestmark = pytest.mark.integration


def fixtures(db):
    now = datetime.now(timezone.utc)
    zone_id = db.zones.insert_one({"name": f"Test Zone {uuid.uuid4()}", "description": None, "location": {}, "active": True, "created_at": now, "updated_at": now}).inserted_id
    space_id = db.spaces.insert_one({"zone_id": zone_id, "code": "T-01", "space_type": "standard", "location_details": None, "active": True, "state_version": 1, "created_at": now, "updated_at": now}).inserted_id
    rebuild_redis()
    return zone_id, space_id


def test_zone_space_crud_and_unique_code(clean_app):
    with clean_app.app_context():
        db = mongo(); zone_id, space_id = fixtures(db)
        assert db.zones.find_one({"_id": zone_id})
        db.spaces.update_one({"_id": space_id}, {"$set": {"location_details": "Updated"}})
        assert db.spaces.find_one({"_id": space_id})["location_details"] == "Updated"
        with pytest.raises(DuplicateKeyError):
            db.spaces.insert_one({"zone_id": zone_id, "code": "T-01", "active": True})


def test_entry_exit_idempotency_and_invariants(clean_app):
    with clean_app.app_context():
        db = mongo(); zone_id, space_id = fixtures(db)
        session, repeated = record_entry(space_id, "TEST-001", "entry-1")
        assert not repeated and zone_counts(zone_id)["occupied"] == 1
        _, repeated = record_entry(space_id, "TEST-001", "entry-1")
        assert repeated
        with pytest.raises(ParkingConflict): record_entry(space_id, "TEST-002", "entry-2")
        completed, repeated = record_exit(space_id, "exit-1")
        assert not repeated and completed["duration_seconds"] >= 0
        _, repeated = record_exit(space_id, "exit-1")
        assert repeated
        with pytest.raises(ParkingConflict): record_exit(space_id, "exit-2")
        assert not verify_invariants()


def test_invalid_exit_timestamp_and_inactive_space(clean_app):
    with clean_app.app_context():
        db = mongo(); _zone_id, space_id = fixtures(db)
        future = datetime.now(timezone.utc) + timedelta(hours=1)
        record_entry(space_id, operation_id="future-entry", entered_at=future)
        with pytest.raises(ParkingConflict): record_exit(space_id, "early-exit", datetime.now(timezone.utc))
        # Occupied spaces cannot safely be treated as inactive by lifecycle handlers.
        assert db.sessions.count_documents({"space_id": space_id, "exit_at": None}) == 1


def test_concurrent_entry_has_one_winner(clean_app):
    db_name = clean_app.config["MONGO_DB"]
    with clean_app.app_context():
        _zone_id, space_id = fixtures(mongo())
    def attempt(index):
        with clean_app.app_context():
            try:
                record_entry(space_id, operation_id=f"race-{index}")
                return "ok"
            except ParkingConflict:
                return "conflict"
    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = list(pool.map(attempt, [1, 2]))
    assert outcomes.count("ok") == 1
    with clean_app.app_context():
        assert mongo().sessions.count_documents({"space_id": space_id, "exit_at": None}) == 1


def test_rebuild_after_project_redis_loss(clean_app):
    with clean_app.app_context():
        db = mongo(); zone_id, space_id = fixtures(db)
        record_entry(space_id, operation_id="rebuild-entry")
        clear_project_state()
        assert zone_counts(zone_id) is None
        rebuild_redis(clear_existing=True)
        assert zone_counts(zone_id)["occupied"] == 1
        assert not verify_invariants()


def test_partial_redis_failure_is_durable_and_retryable(clean_app, monkeypatch):
    with clean_app.app_context():
        db = mongo(); _zone_id, space_id = fixtures(db)
        import app.parking_service as service
        monkeypatch.setattr(service, "apply_space_state", lambda *args, **kwargs: (_ for _ in ()).throw(RedisError("synthetic outage")))
        with pytest.raises(PartialIntegrationError): record_entry(space_id, operation_id="partial-entry")
        assert db.sessions.count_documents({"entry_operation_id": "partial-entry"}) == 1
        assert db.operations.find_one({"operation_id": "partial-entry"})["status"] == "pending_redis"


def test_history_filters_and_availability_agreement(clean_app):
    with clean_app.app_context():
        db = mongo(); zone_id, space_id = fixtures(db)
        record_entry(space_id, operation_id="agreement-entry")
        start = datetime.now(timezone.utc) - timedelta(minutes=1)
        assert db.sessions.count_documents({"zone_id": zone_id, "entry_at": {"$gte": start}}) == 1
        capacity = db.spaces.count_documents({"zone_id": zone_id, "active": True})
        occupied = db.sessions.count_documents({"zone_id": zone_id, "exit_at": None})
        assert capacity - occupied == zone_counts(zone_id)["vacant"]
