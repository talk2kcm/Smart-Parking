# Smart Parking Availability System

## Part 1 — Academic report

### Abstract

This project implements a small smart-parking information system using two complementary NoSQL technologies. MongoDB stores infrastructure documents, durable parking sessions, and operation-recovery evidence. Redis stores a rebuildable, versioned projection of current vacancy and occupancy. The design aims to help an operator publish reliable availability and analyse demand while explicitly handling concurrency, retries, partial failures, and loss of operational state. The application can support the intent of Sustainable Development Goal (SDG) 11 through better-managed urban infrastructure and may support SDG 13 if accurate availability reduces unnecessary search driving. This is an intended pathway, not a measured emissions result.

### 1. Sustainable-development context

The 17 UN Sustainable Development Goals form an integrated agenda covering social, environmental, and economic development (United Nations, n.d.-a). SDG 11 calls for inclusive, safe, resilient, and sustainable cities; its targets include sustainable transport and integrated urban planning (United Nations, n.d.-b). SDG 13 calls for urgent climate action, including integration of climate measures into planning and improved awareness and capacity (United Nations, n.d.-c).

Parking is a modest but relevant urban data problem. Drivers searching for a space add movement that serves no transport destination. Shoup (2006) reviewed evidence showing that cruising could represent a material share of traffic in particular surveyed locations, while later smart-parking reviews describe heterogeneous sensor, communication, and information architectures (Barriga et al., 2019; Fahim et al., 2021). Those findings do not establish that this classroom application reduces emissions. They justify a plausible mechanism: if real availability is accurate, reachable, and acted upon, search time could fall. Measuring that outcome would require field data, a baseline, driver behaviour controls, and an emissions method.

### 2. NoSQL paradigms and relational alternatives

“NoSQL” covers several non-relational models rather than one uniform technology. A document database stores self-describing, nested records and supports queries over document fields. A key-value/data-structure server addresses values through explicit keys and can offer specialised structures such as hashes, sets, and sorted sets. These paradigms suit different access patterns.

MongoDB fits zones, spaces, and sessions because these records have evolving attributes, nested location fields, indexed history queries, and aggregation needs. Its strengths here are expressive document queries, persistent storage, compound and partial indexes, and aggregation. Its costs include index/storage overhead, operational administration, and the fact that flexibility does not remove the need for application validation. MongoDB documentation confirms that a unique partial index constrains only documents matching its filter; the implementation uses this to allow many completed sessions while preventing two sessions with `exit_at: null` for one space (MongoDB, 2026a).

Redis fits the current-state projection because hashes hold compact counters and metadata, sets encode mutually exclusive membership, and a sorted set maintains occupancy ranking by score. Redis documents sets as unique-string collections and sorted sets as unique members ordered by score (Redis, 2026a, 2026b). Server-side Lua is used because Redis guarantees atomic script execution, enabling coordinated changes across the state hash, membership sets, count hash, and ranking (Redis, 2026c).

A relational database remains a strong alternative. Foreign keys, check constraints, and ACID transactions could express zones, spaces, and sessions with excellent integrity, and PostgreSQL can also store flexible JSON. Reporting with joins may be simpler than coordinating two databases. The two-store design is justified by the assessment’s requirement and by its distinct access patterns, not by claiming NoSQL is universally superior. Polyglot persistence adds failure modes, duplicated derived state, memory cost, and operational work.

### 3. Comparison in this context

| Concern | MongoDB document layer | Redis operational layer | Relational alternative |
|---|---|---|---|
| Primary role | Durable entities, history, recovery evidence | Current, rebuildable projection | Could combine durable entities and transactions |
| Schema flexibility | Natural nested location documents; application validation still required | Explicit key contract; weak ad-hoc querying | Strong declared schema; JSON available where needed |
| Querying | Field indexes and aggregation for history/demand | Key/set lookup and sorted-set ranking | Joins, constraints, mature analytical SQL |
| Durability | Persistent system of recovery record | AOF enabled in Compose, but still treated as rebuildable | Strong when correctly configured |
| Atomic scope | Atomic single-document changes; unique indexes enforce key invariants | One Lua script updates related keys atomically | Multi-table transactions are a major strength |
| Scaling | Replication/sharding available with design trade-offs | Replication/cluster options; key design matters | Product-dependent replication/partitioning |
| Efficiency | Appropriate for indexed persistent queries | Very low-latency memory-oriented current-state access | Often entirely sufficient for this project’s scale |

Availability is a system property rather than a database label. Replication, deployment topology, failure detection, and client policy determine behaviour. Likewise, “performance” must be measured for a defined dataset and operation, not inferred from product category.

### 4. Smart-city data model and allocation

The model separates relatively stable infrastructure from time-varying events and derived state:

- A zone describes a fictional location and its lifecycle.
- A space belongs to one zone, has a unique code within it, and carries a monotonic `state_version`.
- A session records one entry and optional exit. An open session is durable recovery evidence that a space is occupied; it is not a duplicate of the whole live dataset.
- An operation records an idempotency key and integration status.
- Redis derives current state from active zones/spaces and open sessions.

This allocation keeps history in the database designed for persistent querying and uses Redis only where its structures materially simplify current-state access. It does not copy complete zone, space, or session documents into Redis.

### 5. Data flow, consistency, and recovery

MongoDB and Redis cannot participate in one atomic transaction. The implemented strategy is a recoverable dual write:

1. Acquire a short per-space Redis lock using a random ownership token. Safe release uses Lua to delete only a lock owned by that token.
2. Insert or retrieve a durable operation with a unique caller-supplied operation ID.
3. Validate zone/space lifecycle and current durable session state.
4. Insert an open session for entry, or atomically close the open session for exit. Unique indexes stop duplicate open sessions and duplicate operation linkage.
5. Increment the space’s persistent `state_version` and mark the operation `mongo_applied`.
6. Run a Redis Lua script. It ignores lower versions, changes set membership, recomputes counters from set cardinality, and updates the occupancy ranking atomically.
7. Mark the operation `synced`. If Redis fails, retain `pending_redis`, display a degraded message, and do not claim fully synchronized success.

The lock reduces competing work but is not the correctness boundary: it can expire during a slow operation. MongoDB uniqueness and idempotency constraints remain authoritative. Retry detects an existing operation/session. A global reconciliation lock blocks new per-space locks; reconciliation waits for any earlier holder, re-reads MongoDB, and applies versioned state. The 120-second reconciliation lease is a practical bound, not an absolute guarantee for arbitrarily slow work. Version checks protect against a delayed older repair.

After Redis loss, the command deletes only keys under the configured project prefix (never unrelated keys), loads active zones and spaces, derives occupancy from open sessions, explicitly initialises empty zones, retries pending operations, and verifies invariants. It never treats an empty Redis database as “all vacant.”

### 6. Performance methodology

`scripts/benchmark.py` creates a unique benchmark database and Redis prefix, 200 active spaces, and 1,000 completed historical sessions. It measures MongoDB space insert/read/update; session insert/read/update; Redis state read/update; balanced integrated entry-plus-exit cycles; and equivalent MongoDB-calculated versus Redis-maintained availability. It uses `time.perf_counter_ns()`, five default warm-ups, 50 default measured iterations, and reports sample count, mean, median, p95, and errors. Timings are client-observed and include client/server round trips; dataset creation and cleanup are outside the samples where practical.

The availability comparison uses `active space count − durable open session count` in MongoDB and the vacant counter in Redis after rebuilding to a stable common state. The script fails if values disagree. Output is raw CSV, summary CSV/JSON, and a median-latency PNG. The isolated database and key prefix are removed afterward.

The benchmark was executed on 8 October 2026 using Python 3.12.10, MongoDB 7.0.17, and Redis 5.0.14.1 on Windows 10. All samples completed without error. MongoDB calculated 200 vacant spaces and Redis returned 200, satisfying the required equivalent-value check. Redis counter retrieval had a 0.699 ms median versus 15.278 ms for the MongoDB calculation in this local experiment. This result is workload- and machine-specific; maintaining Redis counters still costs memory, update work, reconciliation logic, and consistency risk.

### 7. Part 1 conclusion

The design demonstrates why database selection should follow access patterns. MongoDB provides queryable, durable evidence; Redis provides an efficient operational projection. The combination is useful only because failure and recovery are treated as first-class requirements. Sustainability benefit remains a plausible intended contribution requiring empirical evaluation beyond this software assessment.

## Part 2 — Design, implementation, and evaluation

### 8. Requirements traceability

| Requirement | Implementation | Verification |
|---|---|---|
| Zone CRUD/lifecycle | `app/routes.py`: `/zones*` | `test_zone_space_crud_and_unique_code`; demo steps 2–3 |
| Space CRUD, unique per zone | routes plus `uq_zone_space_code` in `app/db.py` | integration duplicate-key test |
| Occupied lifecycle restrictions | toggle/delete routes query open sessions | demo invalid operation; integration lifecycle test |
| Current availability | Redis hashes/sets; dashboard and `/api/availability` | invariant and agreement tests |
| Retry-safe entry/exit | `app/parking_service.py`; unique operation indexes | idempotency/concurrency tests |
| Durable history | `sessions`, history filters/pagination | history filter test |
| Demand | Redis sorted set (current); MongoDB entry aggregation (historical) | demand page/demo |
| Partial failure disclosure | `pending_redis`, warning flash, dashboard count | synthetic Redis-failure test |
| Rebuild/reconciliation | `app/reconciliation.py`, `scripts/reconcile.py` | Redis-loss test |
| Seed ≥3 × 25 | `scripts/seed.py` | seed invariant check |
| Performance harness | `scripts/benchmark.py` | availability agreement and exported outputs |

### 9. Architecture and information flow

```mermaid
flowchart LR
    Browser --> Flask[Flask / validation]
    Flask -->|durable write and queries| MongoDB[(MongoDB)]
    Flask -->|atomic Lua projection| Redis[(Redis)]
    MongoDB -->|zones, spaces, sessions, operations| Reconcile[Reconciliation]
    Reconcile -->|versioned rebuild| Redis
    Redis -->|counts, sets, ranking| Flask
```

All application logic, validation, database calls, reconciliation, and benchmarks are Python. Jinja renders HTML; one small JavaScript file refreshes the Python-backed availability endpoint every 15 seconds.

### 10. MongoDB collections and indexes

**`zones` example:**

```json
{"_id":"ObjectId", "name":"Banksia Civic Centre", "description":"...", "location":{"address":"88 Example Avenue","level":"North deck"}, "active":true, "created_at":"UTC", "updated_at":"UTC"}
```

**`spaces` example:**

```json
{"_id":"ObjectId", "zone_id":"ObjectId", "code":"Z2-04", "space_type":"accessible", "location_details":"Row A, bay 4", "active":true, "state_version":3}
```

**`sessions` example:**

```json
{"space_id":"ObjectId", "zone_id":"ObjectId", "space_code":"Z2-04", "vehicle_id":"OPEN-004", "entry_at":"UTC", "exit_at":null, "duration_seconds":null, "entry_operation_id":"unique", "exit_operation_id":null}
```

**`operations` example:**

```json
{"operation_id":"client UUID", "kind":"entry", "space_id":"ObjectId", "status":"pending_redis", "session_id":"ObjectId", "state_version":3, "updated_at":"UTC", "error":"sanitised diagnostic"}
```

Indexes include unique zone name; unique `(zone_id, code)`; zone/active lookup; history `(zone_id, entry_at desc)` and `(space_id, entry_at desc)`; partial unique open session per `space_id`; unique entry/exit operation linkage; unique operation ID; and operation recovery status/time. Python validation supplies required fields, lengths, enums, identifiers, lifecycle rules, and UTC-aware timestamps. A production extension should add MongoDB collection-level JSON Schema validation.

### 11. Redis key catalogue

`{p}` means `REDIS_PREFIX` (default `parking`). Essential operational keys have no TTL.

| Pattern | Type | Purpose | TTL | Update rule |
|---|---|---|---|---|
| `{p}:space:{space_id}:state` | Hash | `state`, MongoDB `version`, zone, update time | None | Lua accepts same/newer version; older ignored |
| `{p}:zone:{zone_id}:counts` | Hash | capacity, vacant, occupied, initialized, update time | None | Lua recomputes from set cardinalities |
| `{p}:zone:{zone_id}:vacant` | Set | active vacant space IDs | None | Lua removes old membership, adds new |
| `{p}:zone:{zone_id}:occupied` | Set | active occupied space IDs | None | Same atomic script; mutually exclusive |
| `{p}:zones:occupancy` | Sorted set | zone IDs scored by occupancy percentage | None | Lua recalculates after each transition |
| `{p}:lock:space:{space_id}` | String | short coordination lease with owner token | 10 s | `SET NX PX`; token-checked Lua release |
| `{p}:lock:reconcile` | String | prevents new live locks during rebuild | 120 s | owner token; token-checked release |

No complete MongoDB document is cached. The count hash is a derived read model; sets allow counts to be recomputed atomically and verified.

### 12. Invariants and failure behavior

The Lua script and verifier enforce or detect: non-negative values; `vacant + occupied = capacity`; mutual exclusion of sets; occupied not exceeding capacity; inactive exclusion; counter/member agreement; and MongoDB/Redis agreement. MongoDB’s partial unique index enforces at most one open session. Invalid input, duplicate requests, unavailable data, and partial integration return clear operator messages without credentials or stack traces.

### 13. Installation and sample data

See `README.md` for exact commands. `.env.example` contains configuration without secrets. Docker Compose uses MongoDB 7.0 and Redis 7.2 with AOF. The seed creates three fictional zones, 75 spaces of four types, one inactive space, completed sessions across seven days, and ten open sessions, then rebuilds Redis and checks invariants. `--reset` is required to replace existing project data.

### 14. Test cases and actual outcomes

| Area | Case | Expected | Authoring-host outcome |
|---|---|---|---|
| Validation | required fields, length, type, date | reject invalid values | Passed |
| CRUD | zone/space create/read/update and duplicate code | valid changes; duplicate rejected | Passed |
| Lifecycle | duplicate entry/exit, inactive/occupied restrictions | conflict, no corruption | Passed |
| Concurrency | two entry threads for one space | one open session | Passed |
| Invariants | sets/counters and MongoDB availability | all agree | Passed |
| Recovery | remove project Redis state and rebuild | occupied state restored | Passed |
| Partial failure | synthetic Redis exception after Mongo write | durable session + pending operation | Passed |

Unit and integration tests are clearly separated by the `integration` marker. Integration fixtures use randomly named real databases and prefixes, never normal application data. Commands are in the README.

### 15. Benchmark results and interpretation

Status: **measured successfully**. The benchmark used 50 samples after 5 warm-ups, 200 stable active spaces, and 1,000 initial historical sessions. All operations reported zero errors. Selected results are shown below; full raw and summary evidence is in `results/`.

| Operation | Mean ms | Median ms | P95 ms | Errors |
|---|---:|---:|---:|---:|
| MongoDB space read | 1.680 | 1.707 | 2.087 | 0 |
| MongoDB history read | 1.071 | 0.957 | 1.485 | 0 |
| Redis availability read | 0.356 | 0.351 | 0.437 | 0 |
| Redis state update | 0.923 | 0.900 | 1.086 | 0 |
| Integrated entry + exit cycle | 44.338 | 44.284 | 54.902 | 0 |
| MongoDB availability calculation | 15.968 | 15.278 | 19.647 | 0 |
| Redis counter retrieval | 0.728 | 0.699 | 0.888 | 0 |

The Redis counter retrieval was substantially faster in this local workload, but it is a maintained derived value rather than an equivalent-cost query. Its benefit is purchased with dual-write complexity, memory use, and recovery responsibilities. These figures must not be generalized to other machines or workloads without measurement.

### 16. Limitations and future work

- The demo has no authentication or authorisation; production operators need roles, CSRF protection, TLS, rate limiting, and secret management.
- MongoDB standalone mode does not provide a multi-document transaction; the recovery protocol is deliberate but more complex than one relational transaction.
- Locks are leases and may expire. Unique constraints and versions protect core correctness, but long-running reconciliation should renew its lease in a production implementation.
- Reconciliation is simple and suitable for this dataset; large estates should use staged generations, change streams, or a queue/outbox worker.
- There is no physical sensor integration, reservation, pricing, accessible-user workflow, or map.
- Vehicle IDs are synthetic demonstration data. Real identifiers create privacy, retention, and access-control obligations.
- Sustainability outcomes were not measured. Future evaluation should compare search time/distance and account for induced demand, adoption, sensor error, and lifecycle impacts.

### 17. Suggested team allocation

| Role | Student name | Actual contribution (complete honestly) |
|---|---|---|
| Application and validation lead | __________ | __________ |
| MongoDB/data and testing lead | __________ | __________ |
| Redis/integration and benchmark lead | __________ | __________ |
| Documentation/demo and evaluation lead | __________ | __________ |

For a three-person team, combine the first and documentation roles. These are suggestions only; no contribution is claimed.

### 18. Conclusion

The delivered design satisfies the functional scope with distinct database responsibilities and makes the difficult boundary—cross-database consistency—visible and repairable. Durable open sessions and operation records establish recovery evidence; atomic, versioned Redis updates provide an efficient live view. The system is appropriately small for demonstration while retaining realistic concurrency and failure concepts.

## References (APA 7)

Barriga, J. J., Sulca, J., León, J. L., Ulloa, A., Portero, D., Andrade, R., & Yoo, S. G. (2019). Smart parking in IoT-enabled cities: A survey. *Sustainable Cities and Society, 48*, 101558. https://doi.org/10.1016/j.scs.2019.101558

Fahim, A., Hasan, M., & Chowdhury, M. A. (2021). Smart parking systems: Comprehensive review based on various aspects. *Heliyon, 7*(5), e07050. https://doi.org/10.1016/j.heliyon.2021.e07050

MongoDB. (2026a). *Partial indexes*. https://www.mongodb.com/docs/manual/core/index-partial/

MongoDB. (2026b). *Unique indexes*. https://www.mongodb.com/docs/manual/core/index-unique/

Redis. (2026a). *Redis sets*. https://redis.io/docs/latest/develop/data-types/sets/

Redis. (2026b). *Redis sorted sets*. https://redis.io/docs/latest/develop/data-types/sorted-sets/

Redis. (2026c). *Scripting with Lua*. https://redis.io/docs/latest/develop/programmability/eval-intro/

Shoup, D. C. (2006). Cruising for parking. *Transport Policy, 13*(6), 479–486. https://doi.org/10.1016/j.tranpol.2006.05.005

United Nations. (n.d.-a). *The 17 goals*. Retrieved October 8, 2026, from https://sdgs.un.org/goals

United Nations. (n.d.-b). *Goal 11: Sustainable cities and communities*. Retrieved October 8, 2026, from https://sdgs.un.org/goals/goal11

United Nations. (n.d.-c). *Goal 13: Climate action*. Retrieved October 8, 2026, from https://sdgs.un.org/goals/goal13

All references above were checked against publisher, DOI, vendor, or official UN pages during preparation. Access dates use the client date supplied for this project.
