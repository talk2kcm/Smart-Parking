# Demonstration guide (12–15 minutes)

## Preparation

```powershell
docker compose up -d
.\.venv\Scripts\Activate.ps1
python scripts\seed.py --reset
python wsgi.py
```

Keep a second terminal ready. Open <http://127.0.0.1:5000>.

## Script

1. **Start and health (1 min).** Show `docker compose ps`, the dashboard, two green database indicators, zero pending operations, and availability cards. Explain MongoDB as durable history and Redis as the rebuildable live view.
2. **Create infrastructure (2 min).** On Zones, create “Demo Arts Precinct.” Open it, then create `DAP-01`, type electric. Point out unique code scope and that inactive is different from vacant.
3. **View availability (1 min).** Return to the dashboard or zone. Capacity should include the new active space. Mention the 15-second Python-backed refresh.
4. **Entry and both databases (2 min).** Open the space, enter synthetic vehicle `DEMO-101`, and record entry. Show the space as occupied. In a terminal, optionally inspect:

   ```powershell
   docker compose exec mongodb mongosh smart_parking --quiet --eval "db.sessions.find({space_code:'DAP-01'}).pretty()"
   docker compose exec redis redis-cli HGETALL parking:zone:ZONE_OBJECT_ID:counts
   ```

   Explain that one durable open session exists and Redis membership/counters changed atomically.
5. **Exit and duration (1 min).** Record exit; open recent sessions and show the calculated duration.
6. **Reject invalid operation (1 min).** Attempt exit again. The application reports that the space is vacant and creates no extra completed session. Alternatively, occupy a space and try deactivation.
7. **History and demand (2 min).** Filter history by zone/date. Contrast ongoing versus complete. On Demand, distinguish Redis current occupancy percentage from MongoDB historical entry count.
8. **Tests and evaluation (2 min).** Run:

   ```powershell
   pytest -m "not integration" -v
   pytest -m integration -v
   python scripts\benchmark.py --iterations 50 --warmups 5 --output results
   ```

   Show summary JSON/CSV and chart. Confirm the MongoDB and Redis availability values match before interpreting latency.
9. **Isolated Redis-loss recovery (2 min).** Use a non-production demo prefix/database. Remove only project keys, demonstrate “unavailable,” then recover:

   ```powershell
   docker compose exec redis redis-cli --scan --pattern "parking:*"
   # For the assessed demo, use the app's prefix-scoped Python helper, never FLUSHDB:
   python -c "from app import create_app; from app.redis_state import clear_project_state; a=create_app(); c=a.app_context(); c.push(); print(clear_project_state())"
   python scripts\reconcile.py
   ```

   Refresh the dashboard and show that open sessions reconstructed occupied state.

## Safety notes

- Use only fictional vehicle IDs.
- Never demonstrate `FLUSHDB` or drop a non-isolated database.
- If either database is unavailable, say the system is degraded; do not describe spaces as vacant.
- If benchmark values have not been measured on the demonstration machine, run them live or state “not measured.”

