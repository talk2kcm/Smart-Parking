# Submission checklist

## Run and evidence

- [ ] Copy `.env.example` to `.env`; use no real credentials in submission.
- [ ] `docker compose up -d` and confirm both health checks.
- [ ] Install exact requirements in a virtual environment.
- [ ] Run `python scripts/seed.py --reset`; capture its successful invariant result.
- [ ] Run unit and integration tests; paste actual totals into `docs/REPORT.md` and slides.
- [ ] Run the benchmark with stable services; retain raw CSV, summary CSV/JSON, and PNG.
- [ ] Check `availability_agreement.match` is `true`.
- [ ] Exercise the full demo guide and take current screenshots.

## Documents

- [ ] Replace every blank student name/contribution field honestly.
- [ ] Replace all “not run/not measured” text only when genuine evidence exists.
- [ ] Insert measured tables/chart and screenshots into the Word report and PowerPoint.
- [ ] Inspect page breaks, table widths, diagram labels, slide overflow, and image legibility.
- [ ] Ensure references and in-text citations match APA 7.
- [ ] Confirm no unsupported emissions-reduction claim was added.

## Code and data safety

- [ ] No `.env`, credentials, personal vehicle identifiers, or normal database exports.
- [ ] Source `.py` files remain readable and are included.
- [ ] Docker Compose and seed/reconcile/benchmark scripts are included.
- [ ] Demonstrate only against isolated/demo data; never use `FLUSHDB`.
- [ ] Final archive opens cleanly and contains `README.md`.

