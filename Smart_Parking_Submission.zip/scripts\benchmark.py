"""Run isolated, round-trip latency benchmarks against real MongoDB and Redis."""
import argparse
import csv
import json
import platform
import statistics
import sys
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import create_app
from app.db import mongo, redis_client
from app.parking_service import record_entry, record_exit
from app.reconciliation import rebuild_redis
from app.redis_state import apply_space_state, zone_counts


def percentile(values, q):
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, max(0, int((len(ordered) - 1) * q)))]


def measure(name, iterations, warmups, function, raw):
    errors = 0
    for index in range(warmups + iterations):
        started = time.perf_counter_ns()
        try:
            function(index)
        except Exception as exc:
            errors += 1
            if index >= warmups:
                raw.append({"operation": name, "iteration": index - warmups, "latency_ms": None, "error": type(exc).__name__})
            continue
        elapsed = (time.perf_counter_ns() - started) / 1_000_000
        if index >= warmups:
            raw.append({"operation": name, "iteration": index - warmups, "latency_ms": elapsed, "error": ""})
    values = [row["latency_ms"] for row in raw if row["operation"] == name and row["latency_ms"] is not None]
    return {"operation": name, "samples": len(values), "mean_ms": statistics.fmean(values) if values else None,
            "median_ms": statistics.median(values) if values else None, "p95_ms": percentile(values, .95) if values else None,
            "errors": errors}


def main(iterations, warmups, output_dir):
    suffix = uuid.uuid4().hex[:10]
    app = create_app({"MONGO_DB": f"smart_parking_benchmark_{suffix}", "REDIS_PREFIX": f"parking:benchmark:{suffix}"})
    raw, summary = [], []
    with app.app_context():
        db, redis = mongo(), redis_client()
        versions = {"mongodb": db.client.server_info().get("version"), "redis": redis.info("server").get("redis_version")}
        now = datetime.now(timezone.utc)
        zone_id = db.zones.insert_one({"name": "Benchmark Zone", "description": "Isolated", "location": {}, "active": True, "created_at": now, "updated_at": now}).inserted_id
        space_ids = []
        for i in range(200):
            space_ids.append(db.spaces.insert_one({"zone_id": zone_id, "code": f"B-{i:04d}", "space_type": "standard", "location_details": None, "active": True, "state_version": 1, "created_at": now, "updated_at": now}).inserted_id)
        for i in range(1000):
            entry = now - timedelta(days=i % 30, minutes=i)
            db.sessions.insert_one({"space_id": space_ids[i % 200], "zone_id": zone_id,
                "space_code": f"B-{i % 200:04d}", "vehicle_id": f"BENCH-{i}", "entry_at": entry,
                "exit_at": entry + timedelta(minutes=30), "duration_seconds": 1800,
                "entry_operation_id": f"history-entry-{i}", "exit_operation_id": f"history-exit-{i}", "created_at": entry})
        rebuild_redis(clear_existing=True)

        inserted_spaces, inserted_sessions = [], []
        def mongo_space_insert(i):
            inserted_spaces.append(db.spaces.insert_one({"zone_id": zone_id, "code": f"INS-{i}-{uuid.uuid4().hex}", "space_type": "standard", "active": False, "state_version": 1, "created_at": now, "updated_at": now}).inserted_id)
        def mongo_space_read(i): db.spaces.find_one({"_id": space_ids[i % len(space_ids)]})
        def mongo_space_update(i): db.spaces.update_one({"_id": space_ids[i % len(space_ids)]}, {"$set": {"benchmark_marker": i}})
        def history_insert(i):
            sid = db.sessions.insert_one({"space_id": space_ids[0], "zone_id": zone_id, "space_code": "B-0000", "vehicle_id": None,
                "entry_at": now - timedelta(days=60, seconds=i), "exit_at": now - timedelta(days=60, seconds=i-1), "duration_seconds": 1,
                "entry_operation_id": f"bench-ins-{i}-{uuid.uuid4()}", "exit_operation_id": f"bench-out-{i}-{uuid.uuid4()}", "created_at": now}).inserted_id
            inserted_sessions.append(sid)
        def history_read(i): list(db.sessions.find({"zone_id": zone_id, "entry_at": {"$gte": now - timedelta(days=31)}}).sort("entry_at", -1).limit(20))
        def history_update(i): db.sessions.update_one({"_id": inserted_sessions[i % len(inserted_sessions)]}, {"$set": {"benchmark_marker": i}})
        redis_version = [2]
        def redis_read(i): zone_counts(zone_id)
        def redis_update(i):
            redis_version[0] += 1
            state = "occupied" if redis_version[0] % 2 else "vacant"
            apply_space_state(space_ids[-1], zone_id, state, redis_version[0], require_initialized=True)
        integrated_space = space_ids[-2]
        def integrated_cycle(i):
            token = f"integrated-{i}-{uuid.uuid4()}"
            record_entry(integrated_space, "BENCH-CYCLE", token + "-in")
            record_exit(integrated_space, token + "-out")
        def mongo_availability(i):
            capacity = db.spaces.count_documents({"zone_id": zone_id, "active": True})
            occupied = db.sessions.count_documents({"zone_id": zone_id, "exit_at": None})
            return capacity - occupied
        def redis_availability(i): return zone_counts(zone_id)["vacant"]

        specs = [
            ("mongodb_space_insert", mongo_space_insert), ("mongodb_space_read", mongo_space_read),
            ("mongodb_space_update", mongo_space_update), ("mongodb_history_insert", history_insert),
            ("mongodb_history_read", history_read),
        ]
        for name, func in specs: summary.append(measure(name, iterations, warmups, func, raw))
        summary.append(measure("mongodb_history_update", iterations, 0, history_update, raw))
        for name, func in [("redis_availability_read", redis_read), ("redis_state_update", redis_update)]:
            summary.append(measure(name, iterations, warmups, func, raw))
        # Restore a common stable state before integrated and equivalent-value comparisons.
        rebuild_redis(clear_existing=True)
        for name, func in [("integrated_entry_exit_cycle", integrated_cycle), ("mongodb_availability_calculation", mongo_availability),
                           ("redis_counter_retrieval", redis_availability)]:
            summary.append(measure(name, iterations, warmups, func, raw))
        mongo_value, redis_value = mongo_availability(0), redis_availability(0)
        agreement = mongo_value == redis_value
        metadata = {"measured_at_utc": datetime.now(timezone.utc).isoformat(), "iterations": iterations, "warmups": warmups,
                    "dataset": {"spaces": db.spaces.count_documents({}), "historical_sessions": 1000}, "versions": versions,
                    "runtime": {"python": sys.version, "platform": platform.platform()},
                    "timing_scope": "Client-observed latency including one or more client/server round trips; setup excluded where practical.",
                    "availability_agreement": {"mongodb": mongo_value, "redis": redis_value, "match": agreement}}
        output_dir.mkdir(parents=True, exist_ok=True)
        with (output_dir / "benchmark_raw.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["operation", "iteration", "latency_ms", "error"]); writer.writeheader(); writer.writerows(raw)
        (output_dir / "benchmark_summary.json").write_text(json.dumps({"metadata": metadata, "results": summary}, indent=2), encoding="utf-8")
        with (output_dir / "benchmark_summary.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(summary[0])); writer.writeheader(); writer.writerows(summary)
        try:
            import matplotlib.pyplot as plt
            labels = [row["operation"] for row in summary if row["median_ms"] is not None]
            medians = [row["median_ms"] for row in summary if row["median_ms"] is not None]
            fig, ax = plt.subplots(figsize=(11, 6)); ax.barh(labels, medians, color="#167a55"); ax.set_xlabel("Median client-observed latency (ms)"); ax.set_title("Smart Parking measured operation latency"); fig.tight_layout(); fig.savefig(output_dir / "benchmark_medians.png", dpi=180); plt.close(fig)
        except ImportError:
            metadata["chart_note"] = "matplotlib unavailable; CSV and JSON tables were generated."
        # Cleanup is confined to the unique benchmark DB and prefix.
        db.client.drop_database(db.name)
        cursor = 0
        while True:
            cursor, keys = redis.scan(cursor=cursor, match=f"{app.config['REDIS_PREFIX']}:*", count=250)
            if keys: redis.delete(*keys)
            if cursor == 0: break
    print(json.dumps({"metadata": metadata, "results": summary}, indent=2))
    if not agreement: raise SystemExit("Availability values did not agree; benchmark marked failed.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--output", type=Path, default=Path("results"))
    args = parser.parse_args()
    if args.iterations < 5 or args.warmups < 0: parser.error("Use at least 5 iterations and non-negative warmups")
    main(args.iterations, args.warmups, args.output)
