from flask import current_app, g
from pymongo import ASCENDING, DESCENDING, MongoClient
from redis import Redis


def init_connections(app):
    app.extensions["mongo_client"] = MongoClient(
        app.config["MONGO_URI"], serverSelectionTimeoutMS=2500, tz_aware=True
    )
    app.extensions["mongo_db"] = app.extensions["mongo_client"][app.config["MONGO_DB"]]
    app.extensions["redis"] = Redis.from_url(
        app.config["REDIS_URL"], decode_responses=True, socket_connect_timeout=2.5, socket_timeout=2.5
    )


def mongo():
    return current_app.extensions["mongo_db"]


def redis_client():
    return current_app.extensions["redis"]


def close_connections(_error=None):
    # Clients are application-scoped connection pools and intentionally remain open.
    g.pop("unused", None)


def ensure_indexes(app=None):
    db = (app or current_app).extensions["mongo_db"]
    db.zones.create_index([("name", ASCENDING)], unique=True, name="uq_zone_name")
    db.spaces.create_index([("zone_id", ASCENDING), ("code", ASCENDING)], unique=True, name="uq_zone_space_code")
    db.spaces.create_index([("zone_id", ASCENDING), ("active", ASCENDING)], name="ix_space_zone_active")
    db.sessions.create_index([("zone_id", ASCENDING), ("entry_at", DESCENDING)], name="ix_history_zone_entry")
    db.sessions.create_index([("space_id", ASCENDING), ("entry_at", DESCENDING)], name="ix_history_space_entry")
    db.sessions.create_index(
        [("space_id", ASCENDING)], unique=True,
        partialFilterExpression={"exit_at": None}, name="uq_one_open_session_per_space"
    )
    db.sessions.create_index([("entry_operation_id", ASCENDING)], unique=True, name="uq_session_entry_operation")
    db.sessions.create_index(
        [("exit_operation_id", ASCENDING)], unique=True,
        partialFilterExpression={"exit_operation_id": {"$type": "string"}}, name="uq_session_exit_operation"
    )
    db.operations.create_index([("operation_id", ASCENDING)], unique=True, name="uq_operation_id")
    db.operations.create_index([("status", ASCENDING), ("updated_at", ASCENDING)], name="ix_operation_recovery")

