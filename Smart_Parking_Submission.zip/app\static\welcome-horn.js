(() => {
  let played = false;

  async function playHorn() {
    if (played) return;

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;

    const context = new AudioContext();
    try {
      if (context.state === 'suspended') await context.resume();
      if (context.state !== 'running') throw new Error('Audio playback is blocked');

      const now = context.currentTime;
      const output = context.createGain();
      const toneOne = context.createOscillator();
      const toneTwo = context.createOscillator();
      const toneMix = context.createGain();

      toneOne.type = 'sawtooth';
      toneTwo.type = 'square';
      toneOne.frequency.setValueAtTime(196, now);
      toneTwo.frequency.setValueAtTime(247, now);
      toneMix.gain.setValueAtTime(0.68, now);

      output.gain.setValueAtTime(0.0001, now);
      output.gain.exponentialRampToValueAtTime(0.18, now + 0.045);
      output.gain.setValueAtTime(0.18, now + 2.05);
      output.gain.exponentialRampToValueAtTime(0.0001, now + 2.4);

      toneOne.connect(toneMix);
      toneTwo.connect(toneMix);
      toneMix.connect(output);
      output.connect(context.destination);
      toneOne.start(now);
      toneTwo.start(now);
      toneOne.stop(now + 2.42);
      toneTwo.stop(now + 2.42);
      played = true;

      window.setTimeout(() => context.close(), 2700);
    } catch (_) {
      await context.close();
      throw _;
    }
  }

  function fallbackPlay() {
    playHorn().catch(() => {});
    window.removeEventListener('pointerdown', fallbackPlay);
    window.removeEventListener('keydown', fallbackPlay);
  }

  window.addEventListener('load', () => {
    playHorn().catch(() => {
      window.addEventListener('pointerdown', fallbackPlay, {once: true});
      window.addEventListener('keydown', fallbackPlay, {once: true});
    });
  }, {once: true});
})();
