import os
import uuid
import pytest

from app import create_app


@pytest.fixture(scope="session")
def integration_app():
    suffix = uuid.uuid4().hex[:10]
    app = create_app({
        "TESTING": True,
        "SECRET_KEY": "test-only",
        "MONGO_DB": f"smart_parking_test_{suffix}",
        "REDIS_PREFIX": f"parking:test:{suffix}",
    })
    with app.app_context():
        try:
            app.extensions["mongo_db"].command("ping")
            app.extensions["redis"].ping()
        except Exception as exc:
            pytest.skip(f"Real MongoDB and Redis are required: {exc}")
        yield app
        app.extensions["mongo_client"].drop_database(app.config["MONGO_DB"])
        client = app.extensions["redis"]
        cursor = 0
        while True:
            cursor, keys = client.scan(cursor=cursor, match=f"{app.config['REDIS_PREFIX']}:*", count=200)
            if keys:
                client.delete(*keys)
            if cursor == 0:
                break


@pytest.fixture()
def clean_app(integration_app):
    with integration_app.app_context():
        db = integration_app.extensions["mongo_db"]
        for collection in ("operations", "sessions", "spaces", "zones"):
            db[collection].delete_many({})
        client = integration_app.extensions["redis"]
        cursor = 0
        while True:
            cursor, keys = client.scan(cursor=cursor, match=f"{integration_app.config['REDIS_PREFIX']}:*", count=200)
            if keys: client.delete(*keys)
            if cursor == 0: break
        yield integration_app

