(() => {
  const cards = document.querySelectorAll('[data-zone-id]');
  if (!cards.length) return;
  async function refresh() {
    try {
      const response = await fetch('/api/availability', {headers: {'Accept': 'application/json'}});
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error('availability unavailable');
      for (const zone of data.zones) {
        const card = document.querySelector(`[data-zone-id="${zone.zone_id}"]`);
        if (!card || !zone.available) continue;
        const percent = card.querySelector('.percent');
        const bar = card.querySelector('.bar span');
        const values = card.querySelectorAll('.stats dd');
        if (percent) percent.textContent = `${zone.occupancy_percent}%`;
        if (bar) bar.style.width = `${zone.occupancy_percent}%`;
        if (values.length === 3) [values[0].textContent, values[1].textContent, values[2].textContent] = [zone.vacant, zone.occupied, zone.capacity];
      }
    } catch (_) {
      cards.forEach(card => card.setAttribute('aria-label', 'Live refresh failed; displayed data may be stale'));
    }
  }
  setInterval(refresh, 15000);
})();
