"""Create reproducible fictional demonstration data in MongoDB and Redis."""
import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import create_app
from app.db import mongo
from app.reconciliation import rebuild_redis, verify_invariants
from app.redis_state import clear_project_state


ZONES = [
    ("Harbour Learning Quarter", "14 Fictional Quay", "Ground", True),
    ("Banksia Civic Centre", "88 Example Avenue", "North deck", True),
    ("Solar Park and Ride", "5 Placeholder Road", "East lot", True),
]
TYPES = ["standard", "standard", "standard", "accessible", "electric", "motorcycle"]


def seed(reset=False):
    db = mongo()
    if any(db[name].estimated_document_count() for name in ("zones", "spaces", "sessions", "operations")):
        if not reset:
            raise RuntimeError("Project database contains data. Re-run with --reset to replace only this configured project database.")
        for name in ("operations", "sessions", "spaces", "zones"):
            db[name].delete_many({})
        clear_project_state(include_locks=False)

    now = datetime.now(timezone.utc).replace(microsecond=0)
    zone_docs = []
    for name, address, level, active in ZONES:
        result = db.zones.insert_one({
            "name": name, "description": f"Synthetic demonstration zone for {name}.",
            "location": {"address": address, "level": level}, "active": active,
            "created_at": now, "updated_at": now,
        })
        zone_docs.append(db.zones.find_one({"_id": result.inserted_id}))

    spaces = []
    for zone_no, zone in enumerate(zone_docs, 1):
        for number in range(1, 26):
            active = not (zone_no == 3 and number == 25)
            doc = {
                "zone_id": zone["_id"], "code": f"Z{zone_no}-{number:02d}",
                "space_type": TYPES[(number - 1) % len(TYPES)],
                "location_details": f"Row {chr(64 + ((number - 1) // 8) + 1)}, bay {number}",
                "active": active, "state_version": 1,
                "created_at": now, "updated_at": now,
            }
            doc["_id"] = db.spaces.insert_one(doc).inserted_id
            spaces.append(doc)

    sessions = []
    # Completed history over seven days; deterministic and fictional.
    for day in range(7, 0, -1):
        for index, space in enumerate(spaces[:60:3]):
            entry = now - timedelta(days=day, hours=(index % 8) + 1)
            duration = 1800 + (index % 6) * 900
            sessions.append({
                "space_id": space["_id"], "zone_id": space["zone_id"], "space_code": space["code"],
                "vehicle_id": f"SYN-{day:02d}-{index:03d}", "entry_at": entry,
                "exit_at": entry + timedelta(seconds=duration), "duration_seconds": duration,
                "entry_operation_id": f"seed-complete-entry-{day}-{index}",
                "exit_operation_id": f"seed-complete-exit-{day}-{index}", "created_at": entry,
            })
    if sessions:
        db.sessions.insert_many(sessions)

    # Ten open sessions spread across active zones.
    open_candidates = [item for item in spaces if item["active"] and item["code"].endswith(("01", "04", "07", "10"))]
    for index, space in enumerate(open_candidates[:10]):
        entry = now - timedelta(minutes=20 + index * 7)
        db.sessions.insert_one({
            "space_id": space["_id"], "zone_id": space["zone_id"], "space_code": space["code"],
            "vehicle_id": f"OPEN-{index + 1:03d}", "entry_at": entry, "exit_at": None,
            "duration_seconds": None, "entry_operation_id": f"seed-open-{index}",
            "exit_operation_id": None, "created_at": entry,
        })
    totals = rebuild_redis(clear_existing=True)
    problems = verify_invariants()
    if problems:
        raise RuntimeError("Seed consistency check failed: " + "; ".join(problems))
    return {"zones": len(zone_docs), "spaces": len(spaces), "completed_sessions": len(sessions), **totals}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reset", action="store_true", help="Delete data only from configured project collections and Redis prefix before seeding")
    args = parser.parse_args()
    app = create_app()
    with app.app_context():
        result = seed(args.reset)
        print("Seed completed:", result)

