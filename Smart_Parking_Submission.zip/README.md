# Smart Parking Availability System

A presentation-friendly Flask application that uses MongoDB for durable infrastructure and parking history, and Redis for rebuildable real-time availability. It supports zone/space lifecycle management, retry-safe vehicle entry and exit, history, demand analysis, reconciliation, seeding, tests, and reproducible benchmarks.

## Architecture at a glance

- **MongoDB (source of recovery truth):** `zones`, `spaces`, `sessions`, and durable `operations`. A partial unique index permits at most one open session per space; unique operation IDs make retries safe.
- **Redis (live projection):** per-space versioned state hashes, per-zone vacant/occupied sets and count hashes, and a sorted set of occupancy percentages. A Lua script changes all related structures atomically.
- **Consistency:** MongoDB is updated first. Redis failures are disclosed as `pending_redis`, never reported as fully synchronized. `scripts/reconcile.py` rebuilds only the configured key prefix from active MongoDB records and open sessions. Monotonic `state_version` values prevent an older repair from overwriting newer state.
- **Concurrency:** token-owned, safely released per-space locks reduce contention; MongoDB unique indexes are the correctness backstop. Lock expiry alone is not treated as proof of correctness.

MongoDB and Redis do not share a transaction. See [docs/REPORT.md](docs/REPORT.md) for the failure analysis and key catalogue.

## Start locally

Prerequisites: Python 3.11+, Docker Desktop with Compose.

```powershell
Copy-Item .env.example .env
docker compose up -d
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python scripts\seed.py
python wsgi.py
```

Open <http://127.0.0.1:5000>. If the project database already contains data, deliberate replacement requires `python scripts\seed.py --reset`. This deletes only configured project collections and keys under `REDIS_PREFIX`; it never uses `FLUSHDB`.

## Recovery, tests, and benchmark

```powershell
python scripts\reconcile.py
pytest -m "not integration" -v
pytest -m integration -v
python scripts\benchmark.py --iterations 50 --warmups 5 --output results
```

Integration tests create a randomly named database and Redis prefix, then clean up only those isolated resources. Benchmark outputs are raw CSV, summary CSV/JSON, and a chart when Matplotlib is installed.

## Project map

- `app/routes.py` — Flask workflows, filters, lifecycle validation, and JSON refresh endpoint.
- `app/parking_service.py` — durable idempotent entry/exit integration and pending retry.
- `app/redis_state.py` — Redis key definitions, token locks, and atomic Lua state change.
- `app/reconciliation.py` — MongoDB-to-Redis rebuild and invariant verification.
- `app/db.py` — real clients and MongoDB indexes.
- `scripts/seed.py`, `scripts/reconcile.py`, `scripts/benchmark.py` — reproducible operational commands.
- `tests/` — unit tests plus isolated real-database integration tests.
- `docs/` — assessment report source, demonstration guide, slides source, and checklist.

## Current validation status

Validated on 8 October 2026 with Python 3.12.10, MongoDB 7.0.17, and Redis 5.0.14.1 on Windows 10. All 9 tests passed, including real-database integration tests. The measured benchmark completed with 50 samples per operation, 5 warm-ups, zero errors, and matching availability values in MongoDB and Redis. See `results/README.md` and the exported CSV/JSON/chart files.
