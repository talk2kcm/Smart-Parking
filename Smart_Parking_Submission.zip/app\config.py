import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "development-only-change-me")
    DEBUG = os.getenv("FLASK_DEBUG", "0") == "1"
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
    MONGO_DB = os.getenv("MONGO_DB", "smart_parking")
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    REDIS_PREFIX = os.getenv("REDIS_PREFIX", "parking")
    DISPLAY_TIMEZONE = os.getenv("DISPLAY_TIMEZONE", "Australia/Sydney")
    PAGE_SIZE = int(os.getenv("PAGE_SIZE", "15"))
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

