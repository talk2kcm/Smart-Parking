# Measured benchmark results

Measured successfully on 8 October 2026 with Python 3.12.10, MongoDB 7.0.17, Redis 5.0.14.1, and Windows 10.

- Iterations per operation: 50
- Warm-up iterations: 5
- Errors: 0 for every operation
- MongoDB calculated availability: 200
- Redis maintained availability: 200
- Agreement: passed
- MongoDB availability calculation median: 15.278 ms
- Redis counter retrieval median: 0.699 ms
- Integrated balanced entry/exit cycle median: 44.284 ms

Evidence:

- `benchmark_raw.csv` — every measured sample
- `benchmark_summary.csv` — mean, median, p95, count, and errors
- `benchmark_summary.json` — metadata, environment, equality check, and summaries
- `benchmark_medians.png` — measured median-latency chart

Timings are client-observed and include client/server round trips. Results describe this local environment and dataset, not universal database performance.
