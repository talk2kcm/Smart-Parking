# Smart Parking Availability System — slide source

## Slide 1 — Title

Smart Parking Availability System  
MongoDB + Redis with recoverable real-time state  
Student names: __________  ·  Date: __________

## Slide 2 — Problem and sustainability intent

- Drivers need trustworthy vacancy information; stale data can be worse than no data.
- Intended SDG 11 contribution: data-informed management of urban parking infrastructure.
- Potential SDG 13 pathway: less search driving if availability is accurate and used.
- No measured emissions reduction is claimed.

Visual: SDG intent → reliable information → possible reduced search → outcome requires field evaluation.

## Slide 3 — Requirements delivered

- Zone/space CRUD and safe lifecycle rules
- Real-time capacity, vacancy, occupancy, and rankings
- Retry-safe entry/exit with duration and history
- Filters, pagination, current versus historical demand
- Seed, reconciliation, isolated tests, and benchmark harness

## Slide 4 — Architecture

Use the diagram from `docs/architecture.mmd`.

- Flask owns validation and workflows.
- MongoDB is durable and historical.
- Redis is live, derived, and rebuildable.

## Slide 5 — MongoDB design

- Collections: zones, spaces, sessions, operations
- Unique `(zone_id, code)`
- Partial unique open session per space
- Indexed history by zone/time
- Durable operation status supports recovery

## Slide 6 — Redis design

- Space state hash with monotonic version
- Vacant and occupied sets per zone
- Count hash recalculated from set cardinality
- Sorted-set demand ranking
- No TTL on essential occupancy; TTL only on token-owned locks

## Slide 7 — Entry/exit consistency

1. Token-owned per-space lock
2. Unique durable operation ID
3. MongoDB session change first
4. Persistent version increment
5. Atomic Redis Lua transition
6. Synced or explicitly pending—not silent success

## Slide 8 — Failure and recovery

- Redis failure: durable session + pending operation + warning
- Retry is idempotent
- Empty Redis never means all vacant
- Rebuild from active infrastructure and open sessions
- Version checks prevent an older operation overwriting newer state
- Reconciliation is prefix-scoped and verifies invariants

## Slide 9 — Interface demonstration

Insert screenshots after running: dashboard, occupied space control, history/demand.

Demo path: create → view vacant → enter → reject duplicate → exit → history.

## Slide 10 — Tests

- Unit: validation and date/type parsing
- Real integration: CRUD, idempotency, concurrency, lifecycle, partial failure, recovery, equivalent availability
- Isolated random database/prefix; never normal data
- Actual result: 9/9 tests passed against real MongoDB and Redis

## Slide 11 — Performance evaluation

- 200 active spaces; 1,000 completed sessions; 5 warm-ups; 50 samples by default
- Mean, median, p95, errors; client/server round trips included
- Equivalent MongoDB calculation versus Redis counter and required equality check
- Insert `results/benchmark_medians.png` and summary table after genuine execution
- Availability agreement: MongoDB 200 = Redis 200
- Median: MongoDB calculation 15.278 ms; Redis retrieval 0.699 ms
- All measured operations completed with zero errors

## Slide 12 — Evaluation and conclusion

- Strength: durable evidence plus fast, auditable live projection
- Trade-off: additional memory, writes, failure modes, and repair complexity
- Limits: no sensors/auth/field sustainability measurement; simple lease renewal model
- Future: sensor validation, privacy controls, background outbox, staged rebuild, field study
