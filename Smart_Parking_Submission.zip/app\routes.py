import math
import uuid
from datetime import datetime, timezone

from bson import ObjectId
from flask import Blueprint, current_app, flash, jsonify, redirect, render_template, request, url_for
from pymongo.errors import DuplicateKeyError, PyMongoError
from redis.exceptions import RedisError

from .db import mongo, redis_client
from .parking_service import ParkingConflict, PartialIntegrationError, record_entry, record_exit, utc_now
from .reconciliation import rebuild_redis, verify_invariants
from .redis_state import key, zone_counts
from .validation import (
    SPACE_TYPES, ValidationError, object_id, optional_text, parse_utc_filter,
    required_text, space_type,
)

bp = Blueprint("main", __name__)


def _health():
    health = {"mongodb": False, "redis": False}
    try:
        mongo().command("ping")
        health["mongodb"] = True
    except PyMongoError:
        pass
    try:
        health["redis"] = bool(redis_client().ping())
    except RedisError:
        pass
    return health


def _availability_rows(zones=None):
    db = mongo()
    zones = list(zones if zones is not None else db.zones.find({}).sort("name", 1))
    rows = []
    for zone in zones:
        try:
            counts = zone_counts(zone["_id"]) if zone.get("active") else None
        except RedisError:
            counts = None
        row = {"zone": zone, "counts": counts, "available": counts is not None}
        if counts:
            row["occupancy_percent"] = round(100 * counts["occupied"] / counts["capacity"], 1) if counts["capacity"] else 0.0
        else:
            row["occupancy_percent"] = None
        rows.append(row)
    return rows


@bp.get("/")
def dashboard():
    db = mongo()
    zones = list(db.zones.find({}).sort("name", 1))
    pending = db.operations.count_documents({"status": {"$in": ["prepared", "mongo_applied", "pending_redis"]}})
    health = _health()
    try:
        ranking = redis_client().zrevrange(key("zones", "occupancy"), 0, 4, withscores=True)
    except RedisError:
        ranking = []
    zone_names = {str(item["_id"]): item["name"] for item in zones}
    return render_template(
        "dashboard.html", rows=_availability_rows(zones), health=health, pending=pending,
        ranking=[(zone_names.get(zone_id, "Unknown zone"), score) for zone_id, score in ranking],
        problems=verify_invariants() if health["mongodb"] and health["redis"] else [],
    )


@bp.get("/api/availability")
def availability_api():
    try:
        rows = _availability_rows()
        payload = [{
            "zone_id": str(row["zone"]["_id"]), "zone_name": row["zone"]["name"],
            "active": row["zone"].get("active", False), "available": row["available"],
            **(row["counts"] or {}), "occupancy_percent": row["occupancy_percent"],
        } for row in rows]
        return jsonify({"ok": True, "zones": payload, "generated_at": utc_now().isoformat()})
    except (PyMongoError, RedisError) as exc:
        current_app.logger.warning("Availability endpoint degraded: %s", exc)
        return jsonify({"ok": False, "message": "Operational availability is currently unavailable; no vacancy is assumed."}), 503


@bp.route("/zones", methods=["GET", "POST"])
def zones():
    db = mongo()
    if request.method == "POST":
        try:
            now = utc_now()
            result = db.zones.insert_one({
                "name": required_text(request.form.get("name"), "Zone name", 80),
                "description": optional_text(request.form.get("description"), "Description", 500),
                "location": {
                    "address": optional_text(request.form.get("address"), "Address", 180),
                    "level": optional_text(request.form.get("level"), "Level", 40),
                },
                "active": True, "created_at": now, "updated_at": now,
            })
            rebuild_redis(clear_existing=False)
            flash("Parking zone created.", "success")
            return redirect(url_for("main.zone_detail", zone_id=result.inserted_id))
        except (ValidationError, DuplicateKeyError) as exc:
            flash("Zone name already exists." if isinstance(exc, DuplicateKeyError) else str(exc), "error")
    return render_template("zones.html", rows=_availability_rows())


@bp.get("/zones/<zone_id>")
def zone_detail(zone_id):
    db = mongo()
    zone = db.zones.find_one({"_id": object_id(zone_id, "Zone")})
    if not zone:
        return render_template("error.html", title="Zone not found", message="The parking zone does not exist."), 404
    spaces = list(db.spaces.find({"zone_id": zone["_id"]}).sort("code", 1))
    open_ids = {item["space_id"] for item in db.sessions.find({"zone_id": zone["_id"], "exit_at": None}, {"space_id": 1})}
    for space in spaces:
        space["current_state"] = "inactive" if not space.get("active") or not zone.get("active") else ("occupied" if space["_id"] in open_ids else "vacant")
    return render_template("zone_detail.html", zone=zone, spaces=spaces)


@bp.route("/zones/<zone_id>/edit", methods=["GET", "POST"])
def zone_edit(zone_id):
    db = mongo()
    oid = object_id(zone_id, "Zone")
    zone = db.zones.find_one({"_id": oid})
    if not zone:
        return render_template("error.html", title="Zone not found", message="The parking zone does not exist."), 404
    if request.method == "POST":
        try:
            db.zones.update_one({"_id": oid}, {"$set": {
                "name": required_text(request.form.get("name"), "Zone name", 80),
                "description": optional_text(request.form.get("description"), "Description", 500),
                "location.address": optional_text(request.form.get("address"), "Address", 180),
                "location.level": optional_text(request.form.get("level"), "Level", 40),
                "updated_at": utc_now(),
            }})
            flash("Zone updated.", "success")
            return redirect(url_for("main.zone_detail", zone_id=oid))
        except (ValidationError, DuplicateKeyError) as exc:
            flash("Zone name already exists." if isinstance(exc, DuplicateKeyError) else str(exc), "error")
    return render_template("zone_form.html", zone=zone)


@bp.post("/zones/<zone_id>/toggle")
def zone_toggle(zone_id):
    db = mongo()
    oid = object_id(zone_id, "Zone")
    zone = db.zones.find_one({"_id": oid})
    if not zone:
        flash("Zone not found.", "error")
    elif zone.get("active") and db.sessions.count_documents({"zone_id": oid, "exit_at": None}):
        flash("An occupied zone cannot be deactivated. Exit all vehicles first.", "error")
    else:
        db.zones.update_one({"_id": oid}, {"$set": {"active": not zone.get("active"), "updated_at": utc_now()}})
        rebuild_redis(clear_existing=True)
        flash("Zone reactivated." if not zone.get("active") else "Zone deactivated; history was preserved.", "success")
    return redirect(url_for("main.zones"))


@bp.post("/zones/<zone_id>/delete")
def zone_delete(zone_id):
    db = mongo()
    oid = object_id(zone_id, "Zone")
    linked = db.spaces.count_documents({"zone_id": oid}) or db.sessions.count_documents({"zone_id": oid})
    if linked:
        flash("Zone cannot be deleted because spaces or history refer to it. Deactivate it instead.", "error")
    elif db.zones.delete_one({"_id": oid}).deleted_count:
        rebuild_redis(clear_existing=True)
        flash("Unused zone deleted.", "success")
    else:
        flash("Zone not found.", "error")
    return redirect(url_for("main.zones"))


@bp.route("/spaces", methods=["GET", "POST"])
def spaces():
    db = mongo()
    if request.method == "POST":
        try:
            zone_id = object_id(request.form.get("zone_id"), "Zone")
            zone = db.zones.find_one({"_id": zone_id})
            if not zone:
                raise ValidationError("Zone does not exist.")
            now = utc_now()
            result = db.spaces.insert_one({
                "zone_id": zone_id, "code": required_text(request.form.get("code"), "Space code", 30).upper(),
                "space_type": space_type(request.form.get("space_type")),
                "location_details": optional_text(request.form.get("location_details"), "Location details", 180),
                "active": True, "state_version": 1, "created_at": now, "updated_at": now,
            })
            rebuild_redis(clear_existing=False)
            flash("Parking space created.", "success")
            return redirect(url_for("main.space_detail", space_id=result.inserted_id))
        except (ValidationError, DuplicateKeyError) as exc:
            flash("That code already exists in this zone." if isinstance(exc, DuplicateKeyError) else str(exc), "error")
    zone_filter = request.args.get("zone_id")
    query = {}
    if zone_filter:
        try:
            query["zone_id"] = object_id(zone_filter, "Zone")
        except ValidationError as exc:
            flash(str(exc), "error")
    zones_list = list(db.zones.find({}).sort("name", 1))
    zone_map = {item["_id"]: item for item in zones_list}
    rows = list(db.spaces.find(query).sort([("zone_id", 1), ("code", 1)]))
    open_ids = {item["space_id"] for item in db.sessions.find({"exit_at": None}, {"space_id": 1})}
    for item in rows:
        zone = zone_map.get(item["zone_id"])
        item["zone"] = zone
        item["current_state"] = "inactive" if not item.get("active") or not zone or not zone.get("active") else ("occupied" if item["_id"] in open_ids else "vacant")
    return render_template("spaces.html", spaces=rows, zones=zones_list, types=sorted(SPACE_TYPES), zone_filter=zone_filter)


@bp.get("/spaces/<space_id>")
def space_detail(space_id):
    db = mongo()
    oid = object_id(space_id, "Space")
    space = db.spaces.find_one({"_id": oid})
    if not space:
        return render_template("error.html", title="Space not found", message="The parking space does not exist."), 404
    zone = db.zones.find_one({"_id": space["zone_id"]})
    session = db.sessions.find_one({"space_id": oid, "exit_at": None})
    state = "inactive" if not space.get("active") or not zone or not zone.get("active") else ("occupied" if session else "vacant")
    recent = list(db.sessions.find({"space_id": oid}).sort("entry_at", -1).limit(10))
    return render_template("space_detail.html", space=space, zone=zone, session=session, state=state, recent=recent, operation_id=str(uuid.uuid4()))


@bp.get("/operations")
def operations():
    """Prominent operator console for current state and parking events."""
    db = mongo()
    zones_list = list(db.zones.find({}).sort("name", 1))
    zone_map = {item["_id"]: item for item in zones_list}
    query = {}
    zone_filter = request.args.get("zone_id")
    if zone_filter:
        try:
            query["zone_id"] = object_id(zone_filter, "Zone")
        except ValidationError as exc:
            flash(str(exc), "error")
    spaces_list = list(db.spaces.find(query).sort([("zone_id", 1), ("code", 1)]))
    space_ids = [item["_id"] for item in spaces_list]
    open_sessions = {
        item["space_id"]: item
        for item in db.sessions.find({"space_id": {"$in": space_ids}, "exit_at": None})
    } if space_ids else {}
    rows = []
    for space in spaces_list:
        zone = zone_map.get(space["zone_id"])
        session = open_sessions.get(space["_id"])
        state = (
            "inactive" if not space.get("active") or not zone or not zone.get("active")
            else ("occupied" if session else "vacant")
        )
        rows.append({
            "space": space, "zone": zone, "session": session, "state": state,
            "operation_id": str(uuid.uuid4()),
        })
    return render_template(
        "operations.html", rows=rows, zones=zones_list, zone_filter=zone_filter,
    )


@bp.route("/spaces/<space_id>/edit", methods=["GET", "POST"])
def space_edit(space_id):
    db = mongo()
    oid = object_id(space_id, "Space")
    space = db.spaces.find_one({"_id": oid})
    if not space:
        return render_template("error.html", title="Space not found", message="The parking space does not exist."), 404
    if request.method == "POST":
        try:
            db.spaces.update_one({"_id": oid}, {"$set": {
                "code": required_text(request.form.get("code"), "Space code", 30).upper(),
                "space_type": space_type(request.form.get("space_type")),
                "location_details": optional_text(request.form.get("location_details"), "Location details", 180),
                "updated_at": utc_now(),
            }})
            flash("Space updated.", "success")
            return redirect(url_for("main.space_detail", space_id=oid))
        except (ValidationError, DuplicateKeyError) as exc:
            flash("That code already exists in this zone." if isinstance(exc, DuplicateKeyError) else str(exc), "error")
    return render_template("space_form.html", space=space, types=sorted(SPACE_TYPES))


@bp.post("/spaces/<space_id>/toggle")
def space_toggle(space_id):
    db = mongo()
    oid = object_id(space_id, "Space")
    space = db.spaces.find_one({"_id": oid})
    if not space:
        flash("Space not found.", "error")
    elif space.get("active") and db.sessions.count_documents({"space_id": oid, "exit_at": None}):
        flash("An occupied space cannot be deactivated.", "error")
    else:
        db.spaces.update_one({"_id": oid}, {"$set": {"active": not space.get("active"), "updated_at": utc_now()}, "$inc": {"state_version": 1}})
        rebuild_redis(clear_existing=True)
        flash("Space reactivated." if not space.get("active") else "Space deactivated; it is not counted as vacant.", "success")
    return redirect(request.referrer or url_for("main.spaces"))


@bp.post("/spaces/<space_id>/delete")
def space_delete(space_id):
    db = mongo()
    oid = object_id(space_id, "Space")
    if db.sessions.count_documents({"space_id": oid}):
        flash("Space cannot be deleted because parking history refers to it. Deactivate it instead.", "error")
    elif db.spaces.delete_one({"_id": oid}).deleted_count:
        rebuild_redis(clear_existing=True)
        flash("Unused space deleted.", "success")
    else:
        flash("Space not found.", "error")
    return redirect(url_for("main.spaces"))


@bp.post("/spaces/<space_id>/entry")
def entry(space_id):
    try:
        session, repeated = record_entry(
            object_id(space_id, "Space"), request.form.get("vehicle_id"),
            required_text(request.form.get("operation_id"), "Operation ID", 80),
        )
        flash("Entry request already completed safely." if repeated else "Vehicle entry recorded and live availability updated.", "success")
    except (ValidationError, ParkingConflict) as exc:
        flash(str(exc), "error")
    except PartialIntegrationError as exc:
        flash(str(exc), "warning")
    return redirect(url_for("main.space_detail", space_id=space_id))


@bp.post("/spaces/<space_id>/exit")
def exit_space(space_id):
    try:
        session, repeated = record_exit(
            object_id(space_id, "Space"),
            required_text(request.form.get("operation_id"), "Operation ID", 80),
        )
        flash("Exit request already completed safely." if repeated else f"Vehicle exit recorded. Duration: {session['duration_seconds']} seconds.", "success")
    except (ValidationError, ParkingConflict) as exc:
        flash(str(exc), "error")
    except PartialIntegrationError as exc:
        flash(str(exc), "warning")
    return redirect(url_for("main.space_detail", space_id=space_id))


@bp.get("/history")
def history():
    db = mongo()
    try:
        page = max(1, int(request.args.get("page", 1)))
        start = parse_utc_filter(request.args.get("start"), "Start date")
        end = parse_utc_filter(request.args.get("end"), "End date", end_of_day=True)
        if start and end and end <= start:
            raise ValidationError("End date must be the same as or later than the start date.")
        query = {}
        zone_id = request.args.get("zone_id")
        if zone_id:
            query["zone_id"] = object_id(zone_id, "Zone")
        if start or end:
            query["entry_at"] = {}
            if start: query["entry_at"]["$gte"] = start
            if end: query["entry_at"]["$lt"] = end
    except (ValueError, ValidationError) as exc:
        flash(str(exc) if isinstance(exc, ValidationError) else "Page must be a valid number.", "error")
        page, query = 1, {}
    size = current_app.config["PAGE_SIZE"]
    total = db.sessions.count_documents(query)
    sessions = list(db.sessions.find(query).sort("entry_at", -1).skip((page - 1) * size).limit(size))
    zones_list = list(db.zones.find({}).sort("name", 1))
    zone_names = {item["_id"]: item["name"] for item in zones_list}
    return render_template("history.html", sessions=sessions, zones=zones_list, zone_names=zone_names,
                           page=page, pages=max(1, math.ceil(total / size)), total=total)


@bp.get("/demand")
def demand():
    db = mongo()
    try:
        start = parse_utc_filter(request.args.get("start"), "Start date")
        end = parse_utc_filter(request.args.get("end"), "End date", end_of_day=True)
        if start and end and end <= start:
            raise ValidationError("End date must be the same as or later than the start date.")
    except ValidationError as exc:
        flash(str(exc), "error")
        start = end = None
    match = {}
    if start or end:
        match["entry_at"] = {}
        if start: match["entry_at"]["$gte"] = start
        if end: match["entry_at"]["$lt"] = end
    pipeline = []
    if match: pipeline.append({"$match": match})
    pipeline.extend([{"$group": {"_id": "$zone_id", "entries": {"$sum": 1}}}, {"$sort": {"entries": -1}}])
    historical = list(db.sessions.aggregate(pipeline))
    zones_list = list(db.zones.find({}).sort("name", 1))
    names = {item["_id"]: item["name"] for item in zones_list}
    for row in historical: row["zone_name"] = names.get(row["_id"], "Deleted zone")
    current = [row for row in _availability_rows(zones_list) if row["available"]]
    current.sort(key=lambda row: row["occupancy_percent"], reverse=True)
    return render_template("demand.html", current=current, historical=historical)


@bp.post("/admin/reconcile")
def reconcile():
    try:
        totals = rebuild_redis(clear_existing=True)
        flash(f"Reconciliation completed: {totals['spaces']} spaces rebuilt; {totals['pending_repaired']} pending operations repaired.", "success")
    except (PyMongoError, RedisError) as exc:
        current_app.logger.exception("Reconciliation failed")
        flash("Reconciliation failed; live availability remains unavailable or degraded. Check database logs.", "error")
    return redirect(request.referrer or url_for("main.dashboard"))
