import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone

from flask import current_app

from .db import redis_client


APPLY_STATE_LUA = r"""
local state_key = KEYS[1]
local counts_key = KEYS[2]
local vacant_key = KEYS[3]
local occupied_key = KEYS[4]
local ranking_key = KEYS[5]
local incoming_version = tonumber(ARGV[1])
local new_state = ARGV[2]
local space_id = ARGV[3]
local zone_id = ARGV[4]
local updated_at = ARGV[5]
local require_initialized = ARGV[6]

if require_initialized == '1' and redis.call('HGET', counts_key, 'initialized') ~= '1' then
  return {'ERROR', 'UNINITIALIZED'}
end
local old_version = tonumber(redis.call('HGET', state_key, 'version') or '-1')
if old_version > incoming_version then
  return {'IGNORED', 'STALE'}
end
local old_state = redis.call('HGET', state_key, 'state')
if old_version == incoming_version and old_state == new_state then
  return {'OK', 'IDEMPOTENT'}
end

if old_state == 'vacant' then redis.call('SREM', vacant_key, space_id) end
if old_state == 'occupied' then redis.call('SREM', occupied_key, space_id) end
if new_state == 'vacant' then redis.call('SADD', vacant_key, space_id) end
if new_state == 'occupied' then redis.call('SADD', occupied_key, space_id) end

redis.call('HSET', state_key, 'state', new_state, 'version', incoming_version,
  'zone_id', zone_id, 'updated_at', updated_at)
local vacant = redis.call('SCARD', vacant_key)
local occupied = redis.call('SCARD', occupied_key)
local capacity = vacant + occupied
redis.call('HSET', counts_key, 'vacant', vacant, 'occupied', occupied,
  'capacity', capacity, 'updated_at', updated_at, 'initialized', '1')
local percent = 0
if capacity > 0 then percent = occupied * 100 / capacity end
redis.call('ZADD', ranking_key, percent, zone_id)
return {'OK', tostring(capacity), tostring(vacant), tostring(occupied)}
"""

RELEASE_LOCK_LUA = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end"


class OperationalStateError(RuntimeError):
    pass


def prefix():
    return current_app.config["REDIS_PREFIX"]


def key(*parts):
    return ":".join([prefix(), *[str(part) for part in parts]])


def space_key(space_id):
    return key("space", space_id, "state")


def counts_key(zone_id):
    return key("zone", zone_id, "counts")


def vacant_key(zone_id):
    return key("zone", zone_id, "vacant")


def occupied_key(zone_id):
    return key("zone", zone_id, "occupied")


def ranking_key():
    return key("zones", "occupancy")


@contextmanager
def owned_lock(name, ttl_ms=10000, wait_seconds=2.0, ignore_reconcile=False):
    client = redis_client()
    lock_key = key("lock", name)
    token = uuid.uuid4().hex
    deadline = time.monotonic() + wait_seconds
    acquired = False
    while time.monotonic() < deadline:
        if name.startswith("space:") and not ignore_reconcile and client.exists(key("lock", "reconcile")):
            time.sleep(0.03)
            continue
        if client.set(lock_key, token, nx=True, px=ttl_ms):
            acquired = True
            break
        time.sleep(0.03)
    if not acquired:
        raise OperationalStateError("Another request is already changing this parking space. Please retry.")
    try:
        yield token
    finally:
        client.eval(RELEASE_LOCK_LUA, 1, lock_key, token)


def apply_space_state(space_id, zone_id, state, version, require_initialized=True, updated_at=None):
    if state not in {"vacant", "occupied", "inactive"}:
        raise ValueError("Invalid operational state")
    now = updated_at or datetime.now(timezone.utc).isoformat()
    result = redis_client().eval(
        APPLY_STATE_LUA, 5,
        space_key(space_id), counts_key(zone_id), vacant_key(zone_id), occupied_key(zone_id), ranking_key(),
        int(version), state, str(space_id), str(zone_id), now, "1" if require_initialized else "0"
    )
    if result and result[0] == "ERROR":
        raise OperationalStateError(
            "Live availability is not initialized. Run reconciliation; no vacancy was assumed."
        )
    return result


def zone_counts(zone_id):
    values = redis_client().hgetall(counts_key(zone_id))
    if values.get("initialized") != "1":
        return None
    return {
        "capacity": int(values.get("capacity", 0)),
        "vacant": int(values.get("vacant", 0)),
        "occupied": int(values.get("occupied", 0)),
        "updated_at": values.get("updated_at"),
    }


def clear_project_state(include_locks=False):
    """Delete only this application's operational keys; never FLUSHDB."""
    client = redis_client()
    cursor = 0
    deleted = 0
    pattern = key("*")
    while True:
        cursor, keys = client.scan(cursor=cursor, match=pattern, count=250)
        safe_keys = [
            item for item in keys
            if include_locks or not item.startswith(key("lock"))
        ]
        if safe_keys:
            deleted += client.delete(*safe_keys)
        if cursor == 0:
            break
    return deleted
