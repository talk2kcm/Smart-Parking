from datetime import timezone
import pytest

from app.validation import ValidationError, parse_utc_filter, required_text, space_type


def test_required_text_and_lengths():
    with pytest.raises(ValidationError): required_text("  ", "Name")
    with pytest.raises(ValidationError): required_text("abcd", "Name", 3)
    assert required_text(" Example ", "Name") == "Example"


def test_types_and_date_filters():
    assert space_type("electric") == "electric"
    with pytest.raises(ValidationError): space_type("spaceship")
    parsed = parse_utc_filter("2026-10-08", "Start")
    assert parsed.tzinfo == timezone.utc
    with pytest.raises(ValidationError): parse_utc_filter("08/10/2026", "Start")

