"""Rebuild Redis operational state from durable MongoDB records."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import create_app
from app.reconciliation import rebuild_redis, verify_invariants


if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        totals = rebuild_redis(clear_existing=True)
        problems = verify_invariants()
        print("Reconciliation:", totals)
        if problems:
            print("Invariant failures:")
            for problem in problems:
                print(" -", problem)
            raise SystemExit(1)
        print("All checked invariants pass.")

