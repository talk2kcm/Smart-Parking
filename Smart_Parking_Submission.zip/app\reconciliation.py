import logging
from datetime import datetime, timezone

from .db import mongo, redis_client
from .parking_service import retry_pending_operations
from .redis_state import (
    apply_space_state, clear_project_state, key, owned_lock, ranking_key,
)

logger = logging.getLogger(__name__)


def rebuild_redis(clear_existing=True):
    """Reconstruct project operational keys from durable MongoDB evidence.

    The global reconciliation lock blocks new live per-space locks. Any live request
    that began earlier holds its per-space lock; reconciliation waits for that space
    before reading MongoDB. Per-space monotonic versions stop older snapshots from
    replacing newer state. Unrelated Redis keys are never deleted.
    """
    db = mongo()
    client = redis_client()
    totals = {"spaces": 0, "zones": 0, "occupied": 0, "vacant": 0, "inactive": 0}
    with owned_lock("reconcile", ttl_ms=120000, wait_seconds=5):
        if clear_existing:
            clear_project_state(include_locks=False)
        active_zone_ids = {zone["_id"] for zone in db.zones.find({"active": True}, {"_id": 1})}
        totals["zones"] = len(active_zone_ids)
        for space in db.spaces.find({}).sort([("zone_id", 1), ("code", 1)]):
            with owned_lock(f"space:{space['_id']}", ttl_ms=10000, wait_seconds=10, ignore_reconcile=True):
                # Read again after acquiring the lock so no pre-reconcile live update is missed.
                current = db.spaces.find_one({"_id": space["_id"]})
                if not current:
                    continue
                zone_active = current["zone_id"] in active_zone_ids
                open_session = db.sessions.find_one(
                    {"space_id": current["_id"], "exit_at": None}, {"_id": 1}
                )
                if not current.get("active") or not zone_active:
                    state = "inactive"
                else:
                    state = "occupied" if open_session else "vacant"
                apply_space_state(
                    current["_id"], current["zone_id"], state,
                    current.get("state_version", 0), require_initialized=False,
                    updated_at=datetime.now(timezone.utc).isoformat(),
                )
                totals["spaces"] += 1
                totals[state] += 1
        # Ensure active empty zones are explicitly initialized, avoiding ambiguity.
        now = datetime.now(timezone.utc).isoformat()
        for zone_id in active_zone_ids:
            counts = key("zone", zone_id, "counts")
            if not client.exists(counts):
                client.hset(counts, mapping={
                    "capacity": 0, "vacant": 0, "occupied": 0,
                    "updated_at": now, "initialized": 1,
                })
                client.zadd(ranking_key(), {str(zone_id): 0})
        repaired, failed = retry_pending_operations()
        totals["pending_repaired"] = repaired
        totals["pending_failed"] = failed
    return totals


def verify_invariants():
    db = mongo()
    client = redis_client()
    problems = []
    for zone in db.zones.find({"active": True}):
        zone_id = str(zone["_id"])
        counts = client.hgetall(key("zone", zone_id, "counts"))
        if counts.get("initialized") != "1":
            problems.append(f"Zone {zone_id}: Redis state is uninitialized")
            continue
        vacant_members = client.smembers(key("zone", zone_id, "vacant"))
        occupied_members = client.smembers(key("zone", zone_id, "occupied"))
        if vacant_members & occupied_members:
            problems.append(f"Zone {zone_id}: a space belongs to both state sets")
        capacity = int(counts.get("capacity", -1))
        vacant = int(counts.get("vacant", -1))
        occupied = int(counts.get("occupied", -1))
        mongo_capacity = db.spaces.count_documents({"zone_id": zone["_id"], "active": True})
        mongo_occupied = db.sessions.count_documents({"zone_id": zone["_id"], "exit_at": None})
        if min(capacity, vacant, occupied) < 0 or vacant + occupied != capacity:
            problems.append(f"Zone {zone_id}: invalid Redis counters")
        if len(vacant_members) != vacant or len(occupied_members) != occupied:
            problems.append(f"Zone {zone_id}: counters disagree with set membership")
        if capacity != mongo_capacity or occupied != mongo_occupied:
            problems.append(f"Zone {zone_id}: Redis does not match durable MongoDB state")
    return problems
