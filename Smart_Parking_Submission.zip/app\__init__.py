import logging
from datetime import timezone
from zoneinfo import ZoneInfo
from flask import Flask, render_template
from pymongo.errors import PyMongoError
from redis.exceptions import RedisError

from .config import Config
from .db import close_connections, ensure_indexes, init_connections
from .validation import ValidationError


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    logging.basicConfig(
        level=getattr(logging, app.config["LOG_LEVEL"].upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    init_connections(app)
    if not app.config.get("SKIP_INDEX_SETUP", False):
        try:
            ensure_indexes(app)
        except (PyMongoError, RedisError) as exc:
            app.logger.warning("Database startup check failed; requests will show degraded health: %s", exc)

    from .routes import bp
    app.register_blueprint(bp)
    app.teardown_appcontext(close_connections)

    @app.template_filter("localdt")
    def local_datetime(value):
        if not value:
            return "—"
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(ZoneInfo(app.config["DISPLAY_TIMEZONE"])).strftime("%d %b %Y %H:%M:%S %Z")

    @app.template_filter("duration")
    def duration_filter(seconds):
        if seconds is None:
            return "Ongoing"
        hours, remainder = divmod(int(seconds), 3600)
        minutes, secs = divmod(remainder, 60)
        return f"{hours}h {minutes}m {secs}s"

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("error.html", title="Not found", message="The requested record or page was not found."), 404

    @app.errorhandler(ValidationError)
    def invalid_request(error):
        return render_template("error.html", title="Invalid request", message=str(error)), 400

    @app.errorhandler(500)
    def internal_error(error):
        app.logger.exception("Unhandled request error", exc_info=error)
        return render_template("error.html", title="Service error", message="The request could not be completed. No data was silently accepted."), 500

    return app
